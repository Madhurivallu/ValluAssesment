package TestScenario2;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Duplicate_Product_TestBase {
	
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent1;
	public ExtentTest extentTest;

	
	 static WebDriver driver = null;
	 
	
	@BeforeClass
	public void beforeClass() throws Throwable {
		htmlReporter = new ExtentHtmlReporter("./target/failSC.html");
		htmlReporter.config().setDocumentTitle("Fail Scenario Report");
		htmlReporter.config().setReportName(" Fail Test Results ");
		htmlReporter.config().setTheme(Theme.DARK);

		extent1 = new ExtentReports();
		extent1.setSystemInfo("Tester", "Madhuri");
		extent1.setSystemInfo("Browser", "Chrome");
		extent1.attachReporter(htmlReporter);
	
		//navigate to URL
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.get("https://www.vodacom.co.za/");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(3000);
		
		//Validate Vodacom Webpage
		String Expected_Webpage = "Vodacom page has loaded successfully";
		Assert.assertTrue(Expected_Webpage.contains("Vodacom page has loaded successfully"));
	}
	@BeforeMethod
	public  void TestSuccessfull() {

		
		
		extentTest = extent1.createTest("Purchase by Samsung A33 device Fail");
		extentTest.log(Status.PASS, "Navigate to Vodacom URL https://www.vodacom.co.za/");
		extentTest.log(Status.PASS," Validate Vodacom Webpage has loaded Successfully");
		extentTest.log(Status.PASS," Select Online Only Deals and Click On Buy Now");
		extentTest.log(Status.PASS," Validate Vodacom Webpage has loaded Successfully");
		extentTest.log(Status.PASS, "select device is Samsung A33 success");
		extentTest.log(Status.FAIL, "Invalid Deal details Screen is available ");
		extentTest.log(Status.FAIL, "Invalid Deal details are (Expected Samasung A33 Acutual Samsung A22) not match");
		extentTest.log(Status.FAIL, "Incorrect Deal Price is (Actual price R199 PM, Expect Price R229 PM) not match");
	}
	
		public void Testfailed()
		{
		extentTest = extent1.createTest("Failed Test");
		extentTest.log(Status. FAIL, "Purchase by-product is failed");
		Assert.fail(" fail as purchased by Samsung A33 mobile");

	}
	

	
	@AfterClass
	public void afterClass()
	{
		driver.quit();
		extent1.flush();
		
	}

}
