package TestScenario2;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Duplicate_Product_Details extends Duplicate_Product_TestBase{
	@Test
	//Select a device	
		public static void select_Duplicate_device() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"hotspot-portlet-card-content-cta---3516478518-1\"]")).sendKeys(Keys.ENTER);
		Assert.assertTrue(false);
		Thread.sleep(3000);	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(3000);
		
	//Validate Deal details
		String Actual_Deal_detail = "Samsung A22";
		String Expected_Deal_details = "Samsung A33";
		Assert.assertEquals(Actual_Deal_detail, Expected_Deal_details, "Product deal details are not validate");
	
	//Validate for Deal price 
	    String Actual_price = "R199 PM";
		String Expect_Price = "R229 PM";
		Assert.assertEquals(Actual_price,Expect_Price, "Product deal price is not validate");
					
	 //Select Get this deals
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[3]/div[2]/div[2]/div[2]/div/div[1]/div[6]/div/button")).sendKeys(Keys.ENTER);
		Assert.assertTrue(false);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(3000);
	
	
		}
	
}


