package TestScenario1;


import org.testng.AssertJUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductDetailsTest extends PurchaseProductTestBase {
	@Test
	//Select a device	
		public static void select_device() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"hotspot-portlet-card-content-cta---3516478518-3\"]")).sendKeys(Keys.ENTER);
		Thread.sleep(3000);	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(3000);	
		
		//Click on Get this deals button
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[3]/div[2]/div[2]/div[2]/div/div[1]/div[6]/div/button")).sendKeys(Keys.ENTER);
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(3000);
	
		//Validate Deals details
		String Expected_Deals_details = "Samsung A22";
		Assert.assertTrue(Expected_Deals_details.contains("Samsung A22"));


		//Validate Deal price and Contract Duration and Available Online Fields
	    String Expected_Product_price = "R199 PM";
		String Expected_Product_duration = "36 months";
		String Expected_Available_Online = "Yes";
		Assert.assertTrue(Expected_Product_price.contains("R199 PM"));
		Assert.assertTrue(Expected_Product_duration.contains("36 months"));
		Assert.assertTrue(Expected_Available_Online.contains("Yes"));
		
		//validate Order Summary(Product device, plan, cover details
		String Expected_Product_device = "Samsung Galaxy A22 5g 64gb Light Green";
		String Expected_Product_plan = "RED 500MB 50min + with 50 min,500MB data & 0 SMSs (36 Months)";
		String Expected_Product_Cover_details = "Add summary";
		Assert.assertTrue(Expected_Product_device.contains("Samsung Galaxy A22 5g 64gb Light Green"));
		Assert.assertTrue(Expected_Product_plan.contains("RED 500MB 50min + with 50 min,500MB data & 0 SMSs (36 Months)"));
		Assert.assertTrue(Expected_Product_Cover_details.contains("Add summary"));
		}

}
